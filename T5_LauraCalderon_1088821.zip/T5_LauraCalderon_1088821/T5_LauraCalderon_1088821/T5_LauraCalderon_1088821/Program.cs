﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ingrese 3 numeros");
        double n1, n2, n3;
        n1 = Convert.ToInt32(Console.ReadLine());
        n2 = Convert.ToInt32(Console.ReadLine());
        n3 = Convert.ToInt32(Console.ReadLine());  
        
        Console.WriteLine("Los numeros son " + n1 + n2 + n3);

        double d1, d2, d3;

        d1 = n1 * 7.88;
        d2 = n2 * 7.88;
        d3 = n3 * 7.88;

        Console.WriteLine("En dolares son: " +" " + d1 + " " + d2 + " "+ d3);

        if (d1 < d2 && d1 < d3)
        {
            Console.WriteLine(d3 + " " + d2 + " " + d1);
        }
        else if (d3 < d2 && d1 < d2)
        {
            Console.WriteLine(d2 + " " + d1 + " " + d3);
        }
        else if (d3 < d2 && d2 < d1)
        {
            Console.WriteLine(d1 + " " + d2 + " " + d3);
        }

        

    }
}