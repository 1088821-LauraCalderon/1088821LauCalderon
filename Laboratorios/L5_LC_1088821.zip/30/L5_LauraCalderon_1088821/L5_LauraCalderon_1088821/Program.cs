﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("-----Bienvenido-----");
        Console.WriteLine("1) Verificacion de numeros");
        Console.WriteLine("2) Analisis del dia de la semana ");
        Console.Write(">Ingrese una opcion: ");
        int opcion = Convert.ToInt32(Console.ReadLine());
        if(opcion == 1)
        {
            //Entradas
            Console.WriteLine("Ingrese un número");
            int numero = Convert.ToInt32(Console.ReadLine());
            //procesos
            if (numero > 0)
            {
                Console.WriteLine("Numero positivo");
            }
            else if (numero < 0)
            {
                Console.WriteLine("Numero negativo");
            }
            else if (numero == 0)
            {
                Console.WriteLine("Es cero");
            }
        }
        else if (opcion == 2)
        {
            Console.WriteLine("Ingrese un numero");
            int dia = Convert.ToInt32(Console.ReadLine());
            if (dia == 1)
            {
                Console.WriteLine("Lunes");
            }
            else if (dia == 2)
            {
                Console.WriteLine("Martes");
            }
            else if (dia == 3)
            {
                Console.WriteLine("Miercoles");
            }
            else if (dia == 4)
            {
                Console.WriteLine("Jueves");
            }
            else if (dia == 5)
            {
                Console.WriteLine("Viernes");
            }
            else if (dia == 6)
            {
                Console.WriteLine("Sabado");
            }
            else if (dia == 7)
            {
                Console.WriteLine("Domingo");
            }
            else
            {
                Console.WriteLine("Bobi");
            }
        }
        


        Console.ReadLine();




    }
}