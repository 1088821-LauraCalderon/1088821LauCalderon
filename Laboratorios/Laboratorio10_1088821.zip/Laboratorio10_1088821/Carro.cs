﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio10_1088821
{
    internal class Carro
    {
        private string Marca = "";
        private int  Modelo = 0;
        private double precio = 0;
        private string descripcion = "";
        private double IVA = 0;

        public void SetMarca(string marca)
        {
            if (marca != null && marca != "")
            {
                this.Marca = marca;
            }
        }

        public void SetModelo(int modelo)
        {
            this.Modelo = modelo;
        }

        public void SetPrecio(double precio)
        {
            this.precio= precio;
        }
        public void SetDescripcion(string descripcion)
        {
            this.descripcion = descripcion;
        }
        public void SetIva(double iva)
        {
            this.IVA = iva;
        }
        public string LeerMarca()
        {
            return this.Marca;
        }
        public double LeerPrecio()
        {
            return this.precio;
        }
        public string LeerDescripcion()
        {
            return this.descripcion;
        }
        public double LeerPF()
        {
            return this.precio + (IVA * precio);
        }
        public int LeerModelo()
        {
            return this.Modelo;
        }
    }
}
