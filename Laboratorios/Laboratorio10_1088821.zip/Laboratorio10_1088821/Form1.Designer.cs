﻿namespace Laboratorio10_1088821
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.inputdatos = new System.Windows.Forms.Button();
            this.inputdescripcion = new System.Windows.Forms.RichTextBox();
            this.inputPrecio = new System.Windows.Forms.NumericUpDown();
            this.inputmodelo = new System.Windows.Forms.NumericUpDown();
            this.inputMarca = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.inputIVA = new System.Windows.Forms.NumericUpDown();
            this.Outputpreciofinal = new System.Windows.Forms.Label();
            this.botoncalcularprecio = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.outputdescripcion = new System.Windows.Forms.Label();
            this.outputprecio = new System.Windows.Forms.Label();
            this.outputmodelo = new System.Windows.Forms.Label();
            this.outputmarca = new System.Windows.Forms.Label();
            this.botonactualizar = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputmodelo)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(477, 305);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.inputdatos);
            this.tabPage1.Controls.Add(this.inputdescripcion);
            this.tabPage1.Controls.Add(this.inputPrecio);
            this.tabPage1.Controls.Add(this.inputmodelo);
            this.tabPage1.Controls.Add(this.inputMarca);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(469, 279);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // inputdatos
            // 
            this.inputdatos.Location = new System.Drawing.Point(103, 236);
            this.inputdatos.Name = "inputdatos";
            this.inputdatos.Size = new System.Drawing.Size(282, 23);
            this.inputdatos.TabIndex = 9;
            this.inputdatos.Text = "Cargar Datos";
            this.inputdatos.UseVisualStyleBackColor = true;
            this.inputdatos.Click += new System.EventHandler(this.button2_Click);
            // 
            // inputdescripcion
            // 
            this.inputdescripcion.Location = new System.Drawing.Point(103, 169);
            this.inputdescripcion.Name = "inputdescripcion";
            this.inputdescripcion.Size = new System.Drawing.Size(282, 48);
            this.inputdescripcion.TabIndex = 8;
            this.inputdescripcion.Text = "";
            // 
            // inputPrecio
            // 
            this.inputPrecio.DecimalPlaces = 2;
            this.inputPrecio.Increment = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            this.inputPrecio.Location = new System.Drawing.Point(103, 133);
            this.inputPrecio.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.inputPrecio.Name = "inputPrecio";
            this.inputPrecio.Size = new System.Drawing.Size(282, 20);
            this.inputPrecio.TabIndex = 7;
            this.inputPrecio.ThousandsSeparator = true;
            // 
            // inputmodelo
            // 
            this.inputmodelo.Location = new System.Drawing.Point(103, 98);
            this.inputmodelo.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.inputmodelo.Minimum = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            this.inputmodelo.Name = "inputmodelo";
            this.inputmodelo.Size = new System.Drawing.Size(282, 20);
            this.inputmodelo.TabIndex = 6;
            this.inputmodelo.ThousandsSeparator = true;
            this.inputmodelo.Value = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            // 
            // inputMarca
            // 
            this.inputMarca.Location = new System.Drawing.Point(103, 57);
            this.inputMarca.Name = "inputMarca";
            this.inputMarca.Size = new System.Drawing.Size(282, 20);
            this.inputMarca.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 172);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Descripción";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Precio";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Modelo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Marca";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 31);
            this.label8.TabIndex = 0;
            this.label8.Text = "Carros";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.inputIVA);
            this.tabPage2.Controls.Add(this.Outputpreciofinal);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.outputdescripcion);
            this.tabPage2.Controls.Add(this.outputprecio);
            this.tabPage2.Controls.Add(this.outputmodelo);
            this.tabPage2.Controls.Add(this.outputmarca);
            this.tabPage2.Controls.Add(this.botonactualizar);
            this.tabPage2.Controls.Add(this.botoncalcularprecio);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(469, 279);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ver Datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // inputIVA
            // 
            this.inputIVA.DecimalPlaces = 2;
            this.inputIVA.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.inputIVA.Location = new System.Drawing.Point(104, 146);
            this.inputIVA.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.inputIVA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.inputIVA.Name = "inputIVA";
            this.inputIVA.Size = new System.Drawing.Size(163, 20);
            this.inputIVA.TabIndex = 14;
            this.inputIVA.ThousandsSeparator = true;
            this.inputIVA.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // Outputpreciofinal
            // 
            this.Outputpreciofinal.AutoSize = true;
            this.Outputpreciofinal.Location = new System.Drawing.Point(86, 227);
            this.Outputpreciofinal.Name = "Outputpreciofinal";
            this.Outputpreciofinal.Size = new System.Drawing.Size(62, 13);
            this.Outputpreciofinal.TabIndex = 13;
            this.Outputpreciofinal.Text = "Precio Final";
            // 
            // botoncalcularprecio
            // 
            this.botoncalcularprecio.Location = new System.Drawing.Point(104, 176);
            this.botoncalcularprecio.Name = "botoncalcularprecio";
            this.botoncalcularprecio.Size = new System.Drawing.Size(94, 39);
            this.botoncalcularprecio.TabIndex = 12;
            this.botoncalcularprecio.Text = "Calcular Precio Final";
            this.botoncalcularprecio.UseVisualStyleBackColor = true;
            this.botoncalcularprecio.Click += new System.EventHandler(this.botoncalcularprecio_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Precio Final";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "IVA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Descripción";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Precio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Modelo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Marca";
            // 
            // outputdescripcion
            // 
            this.outputdescripcion.AutoSize = true;
            this.outputdescripcion.Location = new System.Drawing.Point(85, 119);
            this.outputdescripcion.Name = "outputdescripcion";
            this.outputdescripcion.Size = new System.Drawing.Size(63, 13);
            this.outputdescripcion.TabIndex = 4;
            this.outputdescripcion.Text = "Descripción";
            // 
            // outputprecio
            // 
            this.outputprecio.AutoSize = true;
            this.outputprecio.Location = new System.Drawing.Point(85, 96);
            this.outputprecio.Name = "outputprecio";
            this.outputprecio.Size = new System.Drawing.Size(37, 13);
            this.outputprecio.TabIndex = 3;
            this.outputprecio.Text = "Precio";
            // 
            // outputmodelo
            // 
            this.outputmodelo.AutoSize = true;
            this.outputmodelo.Location = new System.Drawing.Point(85, 72);
            this.outputmodelo.Name = "outputmodelo";
            this.outputmodelo.Size = new System.Drawing.Size(42, 13);
            this.outputmodelo.TabIndex = 2;
            this.outputmodelo.Text = "Modelo";
            // 
            // outputmarca
            // 
            this.outputmarca.AutoSize = true;
            this.outputmarca.Location = new System.Drawing.Point(85, 46);
            this.outputmarca.Name = "outputmarca";
            this.outputmarca.Size = new System.Drawing.Size(37, 13);
            this.outputmarca.TabIndex = 1;
            this.outputmarca.Text = "Marca";
            // 
            // botonactualizar
            // 
            this.botonactualizar.Location = new System.Drawing.Point(45, 6);
            this.botonactualizar.Name = "botonactualizar";
            this.botonactualizar.Size = new System.Drawing.Size(350, 34);
            this.botonactualizar.TabIndex = 0;
            this.botonactualizar.Text = "Refrescar";
            this.botonactualizar.UseVisualStyleBackColor = true;
            this.botonactualizar.Click += new System.EventHandler(this.botonactualizar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputmodelo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button inputdatos;
        private System.Windows.Forms.RichTextBox inputdescripcion;
        private System.Windows.Forms.NumericUpDown inputPrecio;
        private System.Windows.Forms.NumericUpDown inputmodelo;
        private System.Windows.Forms.TextBox inputMarca;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label Outputpreciofinal;
        private System.Windows.Forms.Button botoncalcularprecio;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label outputdescripcion;
        private System.Windows.Forms.Label outputprecio;
        private System.Windows.Forms.Label outputmodelo;
        private System.Windows.Forms.Label outputmarca;
        private System.Windows.Forms.Button botonactualizar;
        private System.Windows.Forms.NumericUpDown inputIVA;
    }
}

