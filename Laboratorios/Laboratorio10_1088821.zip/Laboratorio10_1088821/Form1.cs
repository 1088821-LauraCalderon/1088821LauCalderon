﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratorio10_1088821
{
    public partial class Form1 : Form
    {
        Carro Carro = new Carro();
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string marca = inputMarca.Text;
            int modelo = (int)inputmodelo.Value;
            double precio = (double)inputPrecio.Value;
            string descripcion = inputdescripcion.Text;

            Carro.SetMarca(marca);
            Carro.SetDescripcion(descripcion);
            Carro.SetPrecio(precio);
            Carro.SetModelo(modelo);

        }

        private void botonactualizar_Click(object sender, EventArgs e)
        {
            outputmarca.Text = Carro.LeerMarca();
            outputmodelo.Text = Carro.LeerModelo().ToString();
            outputprecio.Text = Carro.LeerPrecio().ToString();
            outputdescripcion.Text = Carro.LeerDescripcion();

        }

        private void botoncalcularprecio_Click(object sender, EventArgs e)
        {
            double IVA = (double)inputIVA.Value;

            Carro.SetIva(IVA);
            Outputpreciofinal.Text = Carro.LeerPF().ToString();

        }
    }
}
