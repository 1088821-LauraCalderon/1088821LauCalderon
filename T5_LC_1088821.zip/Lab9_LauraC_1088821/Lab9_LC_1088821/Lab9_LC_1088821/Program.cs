﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio No. 2");
        Console.WriteLine("Ingrese el monto:");

        int monto = Convert.ToInt32(Console.ReadLine());
        double descuento;
        string adicional;
        double totald;


        if (monto < 400)
        {
            Console.WriteLine("No hay descuento");
        }
        else if (monto >= 400 && monto <= 1000)
        {
            descuento = monto - (monto * 0.07);
            Console.WriteLine("El total es de " + descuento);
            Console.WriteLine("Posee codigo de descuento adicional? ");
            adicional = Console.ReadLine();
            if (adicional == "si")
            {
                totald = descuento - (descuento - ((descuento - (descuento * 0.05))));
                Console.WriteLine("Su nuevo total es de " + totald);
            }
            else
            {
                Console.WriteLine("El total sigue siendo de " + descuento);
            }
        }
        else if (monto > 1000 && monto <= 5000)
        {
            descuento = monto - (monto * 0.10);
            Console.WriteLine("El total es de " + descuento);
            Console.WriteLine("Posee codigo de descuento adicional? ");
            adicional = Console.ReadLine();
            if (adicional == "si")
            {
                totald = descuento - (descuento - ((descuento - (descuento * 0.05))));
                Console.WriteLine("Su nuevo total es de " + totald);
            }
            else
            {
                Console.WriteLine("El total sigue siendo de " + descuento);
            }
        }
        else if (monto > 5000 && monto <= 15000)
        {
            descuento = monto - (monto * 0.15);
            Console.WriteLine("El total es de " + descuento);
            Console.WriteLine("Posee codigo de descuento adicional? ");
            adicional = Console.ReadLine();
            if (adicional == "si")
            {
                totald = descuento - (descuento - ((descuento - (descuento * 0.05))));
                Console.WriteLine("Su nuevo total es de " + totald);
            }
            else
            {
                Console.WriteLine("El total sigue siendo de " + descuento);
            }
        }
        else if (monto > 15000)
        {
            descuento = monto - (monto * 0.25);
            Console.WriteLine("El total es de " + descuento);
            Console.WriteLine("Posee codigo de descuento adicional? ");
            adicional = Console.ReadLine();
            if (adicional == "si")
            {
                totald = descuento - (descuento - ((descuento - (descuento * 0.05))));
                Console.WriteLine("Su nuevo total es de " + totald);
            }
            else
            {
                Console.WriteLine("El total sigue siendo de " + descuento);
            }
        }

        
    }
}